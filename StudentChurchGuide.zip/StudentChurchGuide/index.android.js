import React, { Component } from "react"
import { AppRegistry } from "react-native"
import App from "./src/app"

AppRegistry.registerComponent("StudentChurchGuide", () => App);
