import React, { Component } from "react"
import { WebView } from "react-native"
import SplashScreen from "react-native-splash-screen"

class App extends Component {
  componentDidMount() {
    SplashScreen.hide()
  }

  render() {
    return (
      <WebView
        style={styles.webview}
        source={{ "uri": "http://www.churchsearch.org.uk/3/directory/studentguide" }}
      />
    )
  }
}

const styles = {
  "webview": {
    "width": "100%",
    "height": "100%",
    "position": "absolute",
    "top": 0,
    "left": 0,
    "backgroundColor": "#2c2c2b"
  },
}

export default App
